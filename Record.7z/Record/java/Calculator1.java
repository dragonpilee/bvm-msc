import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code ="Calculator1.class" width=500 height=300>
</applet>*/
public class Calculator1 extends Applet implements ActionListener
{
    JLabel Ib1,Ib2,Ib3;
    JTextField txt1,txt2,txt3;
    JButton btn1,btn2,btn3,btn4,btn5,btn6;
    public void init()
    {
        Ib1=new JLabel("Var 1");
        Ib2=new JLabel("Var 2");
        Ib3=new JLabel("result");
        txt1=new JTextField(10);
        txt2=new JTextField(10);
        txt3=new JTextField(10);
        btn1=new JButton("Add");
        btn2=new JButton("sub");
        btn3=new JButton("multi");
        btn4=new JButton("Div");
        btn5=new JButton("Mod");
        btn6=new JButton("Reset");
        add(Ib1);
        add(txt1);
        add(Ib2);
        add(txt2);
        add(Ib3);
        add(txt3);
        add(btn1);
        add(btn2);
        add(btn3);
        add(btn4);
        add(btn5);
        add(btn6);
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btn5.addActionListener(this);
        btn6.addActionListener(this);
    }
    public void actionPerformed(ActionEvent ae)
    {
        double a=0,b=0,c=0;
        try
        {
            a=Double.parseDouble(txt1.getText());
        }
        catch (NumberFormatException e) 
        {
            txt1.setText("Invalid input");
        }
        try 
        {
            b=Double.parseDouble(txt2.getText());
        }
        catch(NumberFormatException e) 
        {
            txt2.setText("Invalid input");
        }
         if(ae.getSource()==btn1)
        {
            c=a+b;
            txt3.setText(String.valueOf(c));
        }
        
         if(ae.getSource()==btn2)
        {
            c=a-b;
            txt3.setText(String.valueOf(c));
        }
        if(ae.getSource()==btn3)
        {
            c=a*b;
            txt3.setText(String.valueOf(c));
        }
        if(ae.getSource()==btn4)
        {
            c=a/b;
            txt3.setText(String.valueOf(c));
        }
        if(ae.getSource()==btn5)
        {
            c=a%b;
            txt3.setText(String.valueOf(c));
        }
        if(ae.getSource()==btn6)
        {
            txt1.setText("0");
            txt2.setText("0");
            txt3.setText("0");
        }
    }
}



