 
import java.util.Scanner;  // Import the Scanner class 

class Sort
{
    public static void main(String args[])
    {
        
        int[] a=new int[5];
        int temp=0;
        

        Scanner Obj = new Scanner(System.in);  
        System.out.println("values");


        for(int i=0;i<a.length;i++)
        {
           String b=Obj.nextLine();
           a[i]= Integer.parseInt(b);
        }


        for(int i=0;i<a.length;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[i]>a[j])
                {
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                }
            }
        }
        
        System.out.println("after sorting");
        for(int k=0;k<a.length;k++)
        {
            System.out.println(a[k]);
         }
      }
   }






 
