import java.io.*;

 class showfile {
     
     public static void main (String args[]) throws IOException {
    
        int i ;
          
         FileInputStream Fin ;
             
   try
   
    {

    Fin = new FileInputStream (args[0]) ;
      
        }
    
    catch (FileNotFoundException e)
      
              {

     System.out.println("File not Found");
   
           return ;
   
            }


       do
    
         {  i=Fin.read() ;
   
               if(i!=-1)

    System.out.print ((char) i) ;

         } while (i!=-1) ;
     
            Fin.close();
    
           }
 
        }

